import java.io.*;
import java.util.*;

/**
 * <p>Title: CreateFile.java</p>
 * <p>Description: creates a text file which contains a token in each line</p>
 * <p>Copyright: Copyright (c) 2005</p>
 * <p>Company: GU</p>
 * @author Dana Dann�lls
 * @version 1.0
 */

public class Tokenize {

    List<String> words;
    String thisFile ="";

  public Tokenize(String file) {
	words = new LinkedList<String>();
	this.thisFile = file;
	tokenizeFile();
	writeToFile();
  }
    public void tokenizeFile() {
	String str;
	try {
	    BufferedReader in = new BufferedReader(new FileReader(thisFile));
	    
	    while ((str = in.readLine()) != null)  {
		String  currSentence = " ", currWord="";
		
                StringTokenizer st = new StringTokenizer(str);
		str += " ";
		currSentence += str;
		
		while (st.hasMoreTokens())
		    {
			currWord = st.nextToken().toString();
		      	addWord(currWord);
			currWord="";   
		    }
	    }
	    in.close();
	    
	} catch(NoSuchElementException ex) {
	    System.err.println("ERROR: the .txt file formated incorrectly.");
	    System.exit(0);
	} catch (FileNotFoundException ex) {
	    System.err.println("ERROR: Couldn't find acronymsCorpus.ann.txt");
	    System.exit(0);
	} catch (IOException ex) {
	    System.err.println("ERROR: IOException: " + ex.getMessage());
	    System.exit(0);
	}
    }
    
    public void addWord(String word) {
	words.add(word);
    }

/*
 * creates a new file that contains one token int each line  
 *
 */

    public void writeToFile(){
	try {
	    int fileNameLen = thisFile.length();
	    String fileName =  new String(thisFile.substring(0,fileNameLen-4));
	    String tokenFile = new String(fileName+"Token.tt");
	    PrintWriter outFile = new PrintWriter(new FileWriter(tokenFile));
	    for (Iterator wordsItr = words.iterator(); wordsItr.hasNext(); ) {
		outFile.print((String) wordsItr.next());	
		outFile.println();
	    }
	    outFile.close();
	}catch (IOException ex) {
	    System.err.println("ERROR: IOException: " + ex.getMessage());
	    System.exit(0);
	}
    }   
    
    /* public static void main(String args[]){
      Tokenize tokenFile = new Tokenize(args[0]);
	tokenFile.writeToFile();
	}*/

}
