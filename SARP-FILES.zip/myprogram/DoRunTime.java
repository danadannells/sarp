
import java.io.*;

/**
* A class to execvate program on unix server
* 
*/

 public class DoRunTime {

     public DoRunTime(String command, String file){
	 if(command.equals("tnt")){
	     tnT(file);
	 } 
	  if(command.equals("mbl")){  
		 mbl(file);
	   }
     }
     public void mbl(String file) {
	 String str = "-a" +file;
	 String[] cmd = {"Timbl",""+str+"","-f", "../../Timbl5/demos/671vector.data","-t","leave_one_out"};
	 File workDir = new File("../../Timbl5/SPARC/");
	 runTime(cmd, workDir,"mblTestResult0505.txt");

     }
     public void tnT(String file) {
       
	 Tokenize tokenFile = new Tokenize(file);
	 //	 System.out.println("The file " +file + " was successfully tokenized!");
	 int fileNameLen = file.length();
	 String fileName =  new String(file.substring(0,fileNameLen-4));
	 String tokenFileName = new String(fileName+"Token.tt"); //saves the file FileName+Token.tt
	 String taggedFileName = new String(tokenFileName+"s");//the tagged file is saved as FileNameToken.tts
	 

	 // system command to run
	 String[] cmd = {"tnt","sweTagger","../../cling/VT06/theprogram/"+ tokenFileName};
	 // the directory int which to run the command
	 File workDir = new File("../../../TnT/tnt/");
	 //System.out.println("tagging...");
	 runTime(cmd, workDir,taggedFileName);

     }

     public void runTime(String[] cmd, File dir, String outfileName) {
	 //String s = null;
	
	 try {

	     Process p = Runtime.getRuntime().exec(cmd,null,dir);
	     PrintWriter outputFile = new PrintWriter(new FileWriter(outfileName));

	     InputStream is = p.getInputStream() ;
	     int c;
	     while((c=is.read()) != -1)  outputFile.print((char)c);// System.out.print((char)c);
	     is=p.getErrorStream();
	     while((c=is.read()) != -1)  outputFile.print((char)c);//System.out.print((char)c);

	
	     outputFile.close();
	     //    System.out.println("The results were saved to a new tagged file: ~/www/acronymprogram/"+outfileName);
	     p.getInputStream().close();
	     p.getOutputStream().close(); 
	     p.getErrorStream().close();
	     p=null;
	 }
	 catch (Exception e) {
	     System.out.println(e.toString());
	     e.printStackTrace();
	     }
     }
	 
     public static void main(String args[]) {
	 DoRunTime startrun = new DoRunTime("mbl",args[0]);
	 }
}

