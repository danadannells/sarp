//package datastructures;
import java.util.*;
/**
 * A list implementation where all changes of the
 * list is performed by the ListIterator.
 */
public class LList extends AbstractSequentialList {

    private Entry head;
    private int   size;

    private class Entry {
	Object element;
        Entry  next, previous;

        Entry(Object element, Entry next, Entry previous) {
	    this.element  = element;
            this.next     = next;
            this.previous = previous;
        }

        Entry() {
            next     = this;
	    previous = this;
        }
    }  // class Entry

    /*
     * The constructor of an empty list.
     */
    public LList() {
	    head = new Entry();
        size = 0;
    }  // constructor LList

    /**
     * Computes the number of elements in this list.
     * @returns the number of elements in this list.
     */
    public int size() {
	    return size;
    }  //

    /**
    * Returns a list iterator of the elements in this list.
    * @returns the list iterator of the elements in this list.
    */
   public ListIterator listIterator(int index) {
        if ( index >= 0 && index <= size ) {
	    return new LLiterator(index);
	}
	else
	    throw new IndexOutOfBoundsException();
    }  // listIterator


    private class LLiterator implements ListIterator {

        Entry    cursor;
        boolean  remAllowed;
        int      posCursor;

        public LLiterator(int index) {
            for ( posCursor = 0, cursor = head.next;
                  posCursor < index;
                  posCursor++, cursor = cursor.next ) {
            }
        }   //  constructorLLitearor

        public void add(Object o) {
	    cursor.previous = cursor.previous.next
		            = new Entry(o,cursor,cursor.previous);
	    posCursor       = posCursor  + 1;
	    size            = size + 1;
	    remAllowed      = true;
        }  // add

        public boolean hasNext() {
	    return posCursor < size;
        }   //  hasNext

        public Object next() {
	    if ( posCursor < size ) {
		cursor     = cursor.next;
                remAllowed = true;
                posCursor  = posCursor + 1;
                return cursor.previous.element;
            }
            else
		throw new NoSuchElementException();
        }   // next

        public int nextIndex() {
	    return posCursor;
        }

        public boolean hasPrevious() {
	    return posCursor > 0;
        }   // hasPrevious

        public Object previous() {
	    if ( posCursor > 0 ) {
		cursor     = cursor.previous;
                posCursor  = posCursor - 1;
                remAllowed = posCursor == 0 ? false : true;
                return cursor.element;
            }
            else
		throw new NoSuchElementException();
        }   //  previous


        public int previousIndex() {
	    return posCursor - 1;
	}

        public void remove() {
	    if ( remAllowed ) {
		cursor.previous.previous.next = cursor;
                cursor.previous = cursor.previous.previous;
                size            = size - 1;
                remAllowed      = false;
                posCursor       = posCursor -1;
	    }
	    else
		throw new IllegalStateException();
	}

        public void set(Object o) {
            if ( remAllowed )
		cursor.previous.element = o;
	    else
		throw new IllegalStateException();
	}
    }   // class LLitearor

}   // class LList
