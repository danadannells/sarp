
import java.util.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2005</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */
/*
  * Pair is a class for an acronym pair
  * it constract an instans that contains
  * an acronym, a definition and a vector that
  * represent the features which describe each pair
  *
  */
  public class Pair {
    int id;
    String acr;
    String def;
    Vector<Integer> acrVector;
    String isTrue;

    public Pair(String acr, String def) {
                this.acr = acr;
                this.def = def;
    }
       public Pair(int id,String acr, String def) {
             this.id = id;
             this.acr = acr;
             this.def = def;
             this.isTrue = "+";
       }
       public Pair(int id,String acr, String def, String isTrue) {
              this.id = id;
              this.acr = acr;
              this.def = def;
              this.isTrue = isTrue;
        }


  public Pair(int id, String acr, String def, Vector<Integer> acrVector) {
       this.id = id;
       this.acr = acr;
       this.def = def;
       this.acrVector = acrVector;
       addMoreElements();
  }
      public int LowerCaseInAcr(){
      int countLowerCase = 0;
      for(int i=0;i<this.acr.length();i++){
        if(Character.isLowerCase(acr.charAt(i)))
          countLowerCase++;
      }
        return countLowerCase;
      }
      private void  addMoreElements(){
        acrVector.add(new Integer(acr.length()));
        acrVector.add(new Integer(def.length()));
        acrVector.add(new Integer(numOfLowerCase(acr)));
        acrVector.add(new Integer(numOfLowerCase(def)));
        acrVector.add(new Integer(numOfUpperCase(acr)));
        acrVector.add(new Integer(numOfUpperCase(def)));
        acrVector.add(new Integer(numOfWordsInDef()));
      }

      private int numOfLowerCase(String str){
        int lowerCase=0;
        for(int i=0;i<str.length();i++){
          if(Character.isLowerCase(str.charAt(i)))
            lowerCase++;
        }
        return lowerCase;
      }

      private int numOfUpperCase(String str){
        int upperCase=0;
        for(int i=0;i<str.length();i++){
          if(Character.isUpperCase(str.charAt(i)))
            upperCase++;
        }
        return upperCase;
      }
      private int numOfWordsInDef(){
             int wordCount=1;
             for(int i=0;i< this.def.length();i++){
               if(Character.isSpaceChar(def.charAt(i)))
                 wordCount++;
             }
             return wordCount;
           }
           public String getAcronym(){
             return this.acr;
           }
           public String getDefinition(){
             return this.def;
        }
        public String getValue(){
                    return this.isTrue;
               }

      /*
       * MatchFirstLetter()
       *
       *
       */
       public int MatchFirstLetter(){
        if(this.acr.charAt(0) == this.def.charAt(0) ||
           (Character.toLowerCase(this.acr.charAt(0)) == this.def.charAt(0)))
          return  1;
        return 0;
      }
      public Vector getAcrVector(){
      return this.acrVector;
      }
       public boolean equals(Object o) {
        Pair p = (Pair) o;
        return p.acr.equals(this.acr) && p.def.equals(this.def);
             //&& p.acrVector.get(0)==this.acrVector.get(0) && p.acrVector.get(2)==this.acrVector.get(2);
      }
   /*  public boolean equalPair(Pair p, String acrE, String defE) {
        String acrS = p.getAcronym();  //p = (Pair) o;
        String defS = p.getDefinition();
        return acrE.equals(acrS) && defE.equals(defS);
      }
*/
        public int hashCode() {
             return acr.hashCode() + def.hashCode();
          }
    }

