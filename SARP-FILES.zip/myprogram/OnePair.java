 import java.util.*;

/**
   *
   * <p>Title: </p>
   * <p>Description: </p>
   * <p>Copyright: Copyright (c) 2006</p>
   * <p>Company: </p>
   * @author not attributable
   * @version 1.0
   */
 public class OnePair{
   String str1;
   String str2;
   String stringsContext;
   LList allAcronym;
   LinkedList inLine;

   /**
    *
    * @param str1
    * @param str2
    */
   public OnePair(String str1, String str2){
     this.str1 = str1;
     this.str2 = str2;
   }

   public OnePair(LList allAcronym, LinkedList inLine){
    this.allAcronym = allAcronym;
    this.inLine = inLine;
  }
   public String getStr1(){
     return this.str1;
   }
   public String getStr2(){
     return this.str2;
   } 
     public LList getAcrList(){
     return this.allAcronym;
   } 
     public LinkedList getLineList(){
     return this.inLine;
   }
 }
