import java.util.NoSuchElementException;
import java.util.*;
import java.io.*;
import java.text.*;


/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2006</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class AcronymRecognizer {
    //  String taggedInputFile;
    Dictionary acrDictionary;
    Boolean taggedFile = false;
    int c =0,correct=0, count=0;
    LinkedList<OnePair> line;

    LList acronymPairs; //a set of all found acronyms in line
    LinkedList<OnePair> acronymsInlines; //contains the found acronyms in each line
    LinkedList<String> newLine;
    LinkedList<Pair> allAcronymPairs; //a set of all found acronyms in file
    

    public AcronymRecognizer(String inFile, String taggedInputFile) {
	line = new LinkedList<OnePair>();
	acronymPairs = new LList();
	acronymsInlines = new LinkedList<OnePair>();
	newLine= new LinkedList<String>();
	allAcronymPairs = new LinkedList<Pair>();
	
	if(taggedInputFile != null){
	    acrDictionary = new Dictionary(taggedInputFile);
	    taggedFile=true;
    }
	findAcrDefPairs(inFile);
    }
    
    /**
   * findAcrDefPairs(String inFile)
   * The method gather the tokens with thier tags in lines.
   * each line ends with a full stop ('.')
   * @param infile is a tokenized tagged .tts file
   *
   */
  public void findAcrDefPairs(String inFile) {
    try {
      BufferedReader in = new BufferedReader(new FileReader(inFile));
      String str = in.readLine();
      while (str != null) {
        if ( (!str.startsWith("%%") && str.length() > 0) 
	    && aTag(str.charAt(str.length() - 1))) {
          StringTokenizer st = new StringTokenizer(str);
          if (!str.startsWith(".")) {
            String token = st.nextToken().trim();
            String tag = st.nextToken().trim();
            line.add(new OnePair(token, tag));
          }
          if (str.startsWith(".")) {
            String token = st.nextToken().trim();
            String tag = st.nextToken().trim();
            line.add(new OnePair(token, tag));

            // find acronym pairs in each line and save the pairs and the line
            // in the HashSet

        //    lines.add(line);
	    //            showThisLine(line);
            searchTheLine();//line);
           // System.out.println();
          //  count++;
            //showLine(newLine);

            // the acronymPairs list contains all the acronym pairs that where found in the line

	    if(!acronymPairs.isEmpty()){
		getlistItrStr(line.listIterator()); //saves only acr-def (no pos tags) in the newline
  // iterate over the acr list, tag each in the line
		for(Iterator pairsItr = acronymPairs.iterator(); pairsItr.hasNext(); ) {
		    Pair acrPair = (Pair)pairsItr.next();
		    addTag(acrPair.getAcronym(), acrPair.getDefinition()); //tag each acr-def in the new line
		}
		// saves the acronymPairs list and the tagged line
		acronymsInlines.add(new OnePair(acronymPairs,newLine));
	    }
	    //showLine(newLine);
            allAcronymPairs.addAll(acronymPairs);
	    //            c = c+ acronymPairs.size();

	    //System.out.println(correct );

            acronymPairs = new LList();
            line = new LinkedList<OnePair>();
            newLine= new LinkedList<String>(); //contains the string without thier pos tags
          }
        }
        str = in.readLine();
      }
      in.close();
      // System.out.println(acronymPairs.size() + " " +count);
        //acromyns.checkCorrect();
      //   System.out.println("taggedInputFile" + taggedInputFile);
      
      if(taggedFile){
      // if( acrDictionary.getDictionarySize()> 0){
      //	  System.out.println("- ----- taggedInputFile --- " + taggedInputFile);
	  for(Iterator pairsItr = allAcronymPairs.iterator(); pairsItr.hasNext(); ) {
	      Pair acrPair = (Pair)pairsItr.next();
	      
	      checkIfCorrect(acrPair.getAcronym().toString(),acrPair.getDefinition().toString());
	      //  notFound(acrPair.getAcronym().toString());
	  } 
	  }
   
//printCandidates();
//      printResults();
      //System.out.println("allAcronymPairs: " +allAcronymPairs.size() + "\n"+ "C " + c +" Correct Match " +correct );
     
      /*  for (Iterator acrItr = lexicon.getLex(); acrItr.hasNext(); ) {
	   Pair acr = (Pair) acrItr.next();
	   if(!printnotFound(acr.getAcronym()))
	  System.out.println(acr.getAcronym());
	  }*/
      //showLines();
    }
    catch (Exception ioe) {
      ioe.printStackTrace();
    }
  }


  /**
   * Hittar alla acronyms candidates and determines the following and previous context in which
   * to look for the defintion string
   *
   */
 public void searchTheLine(){//LList oneLine) {

   int acrIndex, acrLen,endSearch;
   List followingContext= new LList();
   List previousContext= new LList();

   ListIterator lineItr = line.listIterator();
   OnePair tokenInLine = (OnePair) lineItr.next();
   while (lineItr.hasNext()) {

     if(isAcronymCandidate(tokenInLine.getStr1(),tokenInLine.getStr2())){
      // checkIfCorrect(tokenInLine.getStr1(),"");
	 //	 if(checkCorrect(tokenInLine.getStr1(),""))
	 // count++;

      acrIndex = line.indexOf(tokenInLine);
      acrLen = 4*tokenInLine.getStr1().length(); // determine the search space for the definition candidate
      endSearch = acrIndex +acrLen;

      if(acrIndex > acrLen)
        previousContext = line.subList(acrIndex-acrLen,acrIndex-1);
      if(acrIndex <= acrLen && acrIndex >1)
        previousContext = line.subList(0,acrIndex-1);
      if(acrIndex <= 1)
        previousContext =  new LList();

     /* System.out.println("\n"+ "PREVIOUS:    "+"\n");
      for(Iterator itr = previousContext.iterator(); itr.hasNext();){
        OnePair op = (OnePair)itr.next();
        System.out.print(op.getStr1()+" ");
      }*/

      if(line.size()>endSearch)
        followingContext = line.subList(acrIndex + 1, endSearch);
      if(line.size()<= endSearch)
        followingContext = line.subList(acrIndex + 1, line.size());

      /*
      //DATABASE LOOKUP HERE
      boolean pairFound=false;	
      SqlDbManager sdbm = new SqlDbManager(); 
      ResultSet RS = sdbm.access("SELECT expansion FROM acronymtable where acronym =" +"'"+ tokenInLine.getStr1() +"'");
      try {//check if the expansions i the database match with the context 
      while(RS.next()){
      String DBexpansion =  RS.getString("expansion");
      if(matchWithDBexp(DBexpansion, previousContext,followingContext))
      acronymPairs.add(new Pair(tokenInLine.getStr1(), DBexpansion));
      pairFound =true;
      }
      }catch (java.sql.SQLException sqlex) {
      System.err.println("DbManager.access -- SQLException: " + sqlex);
      }
      
      if(pairFound==false) // do the search
      {    
      */
      reduceSearchSpace(tokenInLine.getStr1(), previousContext, followingContext);
      
      //} end if pairFound==false

        //determineSearchSpace(tokenInLine.getStr1(), line);
    /*  System.out.println("CANDIDATE :   ---- "+ tokenInLine.getStr1() + " " + endSearch+" " +line.size() );

      System.out.println("\n"+ "FOLLOWING:    "+"\n");
      for(Iterator itr = followingContext.iterator(); itr.hasNext();){
        OnePair op = (OnePair)itr.next();
        System.out.print(op.getStr1()+" ");
      }*/
         // System.out.println("\n"+ "LINE:    "+"\n");
         //showThisLine(line);
        // System.out.println();
         //showLine(newLine);
         //showLine(oneLine);
     }
       tokenInLine = (OnePair) lineItr.next();
     }
   }
   /**
    * tries to match an acronym with its currect definition
    * saves the found pair (add them to the acronymPairs hash set)
    * @param candidate
    * @param previousWindow
    * @param followingWindow
    */

   public void reduceSearchSpace(String acrCandidate, List previousWindow, List followingWindow) {
     String definition = "", definition2 = "";
     int searchLen = 2*acrCandidate.length()+1;
     int searchLen2 = searchLen;
     int paren =0;
     ListIterator followItr = followingWindow.listIterator();
     ListIterator prevItr = previousWindow.listIterator(previousWindow.size());
     OnePair followOp = null;

   
   //  if(prevItr.hasNext())
     //  preOp = (OnePair) prevItr.next();
     if(followItr.hasNext())
       followOp  = (OnePair) followItr.next();

       // A(D), A token token (D)
     if (followOp != null && (followOp.getStr1().equals("(")
                              || (followingWindow.size()>1 && followingWindow.get(1).equals("(")
                                  || followingWindow.size()>2 && followingWindow.get(2).equals("(") ))) { 
       while (followItr.hasNext() && !followOp.getStr1().equals(")")) {
         followOp = (OnePair) followItr.next();
         if(followOp.getStr1().equals(";"))
           break;
         if (!followOp.getStr1().equals(")"))
           definition += followOp.getStr1().toString()+ " ";
       }
    if(definition.endsWith(" "))
       definition = new String(definition.substring(0, definition.length()-1));
      acronymPairs.add(new Pair(acrCandidate, definition));


     //  System.out.println("A(D)" + ""+ "Acronym: "+ acrCandidate+"\t" + "Def: " + definition);
      
     }// end if  A(D), A token token (D)

     //D(A) or "D"(A)
     else if(followOp != null && followOp.getStr1().equals(")")){
       while(prevItr.hasPrevious() && searchLen >0 || paren==2){
         OnePair opPrev = (OnePair) prevItr.previous();
         searchLen--;
         if(opPrev.getStr1().equals("\"'"))
           paren++;
         if( opPrev.getStr1().equals(")") || (opPrev.getStr2().equals("C") && !opPrev.getStr1().equals("och"))
            || (opPrev.getStr1().equals(",") && previousWindow.indexOf(opPrev) != previousWindow.size()-1)
            ||  opPrev.getStr1().equals(";")
            ||  opPrev.getStr1().equals(":")
            || (opPrev.getStr2().equals("S") && !opPrev.getStr1().equals("f�r")))
           break;
         else
           definition = opPrev.getStr1().toString() + " " + definition;
       }

       if(definition.endsWith(" "))
       definition = new String(definition.substring(0, definition.length()-1));

       String bestDefinition = findBestSubString(definition);
       //System.out.println(bestDefinition +  "\n " + definition);
       if(bestDefinition!="")
         acronymPairs.add(new Pair(acrCandidate,bestDefinition));
       // acronymPairs.add(new Pair(acrCandidate,definition));

//      acronymPairs.add(new Pair(acrCandidate, new String(definition)));

      // System.out.println( "D(A) 'D'(A)." + ""+"Acronym: "+ acrCandidate+"\t" + "Def: " + definition);
      
     } // end else if D(A) or "D"(A)
     /////////////////////////////////////////////////////////
      //  D,A, or D,A. or "D,A" D-A or D(A..
     else if(followOp != null && !followOp.getStr1().equals("(")
             && (followOp.getStr1().equals(".") || followOp.getStr1().equals(","))
             || followOp.getStr1().equals("\"'")){
       while(prevItr.hasPrevious() && searchLen >0){
         OnePair opPrev = (OnePair) prevItr.previous();
         searchLen--;
         if((opPrev.getStr1().equals(",") && previousWindow.indexOf(opPrev) != previousWindow.size()-1)
            || opPrev.getStr1().equals(";")
            || opPrev.getStr1().equals("(")//added
            || opPrev.getStr1().equals("-")//added
            || opPrev.getStr1().equals(")") || opPrev.getStr1().equals("]")
            || opPrev.getStr1().equals("\"'")|| opPrev.getStr1().equals("att")
            || opPrev.getStr1().equals("�r"))
           break;
         else
           definition = opPrev.getStr1().toString() + " " +definition;
       }
      // acronymPairs.add(new OnePair(acrCandidate, new String(definition)));
     //  System.out.println( "D,A D,A. 1" + ""+"Acronym: "+ acrCandidate+"\t" + "Def: " + definition);
        
       // A, D,
          while(followItr.hasNext() && searchLen2 >0 && !followOp.getStr1().equals("(")){// && !followOp.getStr1().equals(",")) {
            followOp = (OnePair) followItr.next();
            searchLen2--;
            if(followOp.getStr1().equals(",") || followOp.getStr1().equals(".")  ||
               followOp.getStr1().equals("(") ||
               (followOp.getStr2().equals("S") && !followOp.getStr1().equals("f�r"))
               || followOp.getStr1().equals("att") || followOp.getStr1().equals("�r"))
              break;
            else
              definition2 += followOp.getStr1().toString() + " ";
          }
      if(followOp.getStr1().equals("(") && definition2 != ""){

        if(definition2.endsWith(" "))
          definition2 = new String(definition2.substring(0, definition2.length()-1));

        String bestDefinition = findBestSubString(definition2);
        //System.out.println(bestDefinition +  " \n" + definition2);
         if(bestDefinition!="")
        acronymPairs.add(new Pair(acrCandidate,bestDefinition));
      //acronymPairs.add(new Pair(acrCandidate,definition2));
       /// else
        ////acronymPairs.add(new Pair(acrCandidate,new String(definition2)));

            //System.out.println( "A, D, 2 " + ""+ "Acronym: "+ acrCandidate+"\t" + "Def: " + definition);
           definition2 = "";
      }
        //    acronymPairs.add(new OnePair(acrCandidate,definition2));
        //     System.out.println( "A, D, 2 " + ""+ "Acronym: "+ acrCandidate+"\t" + "Def: " + definition2);
       if(definition2 != "")
        chooseOnePair(acrCandidate,definition,definition2);
       else{
         if(definition.endsWith(" "))
           definition = new String(definition.substring(0, definition.length()-1));

         String bestDefinition = findBestSubString(definition);
        // System.out.println(bestDefinition +  "\n " + definition);
          if(bestDefinition!="")
           acronymPairs.add(new Pair(acrCandidate, bestDefinition));
        //acronymPairs.add(new Pair(acrCandidate,definition));
         }
     } // end else if D,A, or D,A. or "D,A" D-A or D(A..
      
     // else if(opPrev.getStr1().equals(";")){//!followOp.getStr1().equals(")") && ( || )){

      //}
        //  A=D A-D
        else if(followOp != null && (followOp.getStr1().equals("-") || followOp.getStr1().equals("="))){
          while(followItr.hasNext()){
            followOp = (OnePair) followItr.next();
            if(followOp.getStr1().equals(",") || followOp.getStr1().equals(".")
		|| (followOp.getStr2().equals("S") && !followOp.getStr1().equals("av") && !followOp.getStr1().equals("f�r")))
              break;
            else
               definition += followOp.getStr1().toString() + " ";
          }

          if(definition.endsWith(" "))
            definition = new String(definition.substring(0, definition.length()-1));
	  
	          String bestDefinition = findBestSubString(definition);
         // System.out.println(bestDefinition +  "\n " + definition);
	         if(bestDefinition!="")
	        acronymPairs.add(new Pair(acrCandidate,new String(bestDefinition)));
	  // acronymPairs.add(new Pair(acrCandidate,definition));
    //System.out.println( "A=D A-D" + ""+ "Acronym: "+ acrCandidate+"\t" + "Def: " + definition);
        
	} // end else if A=D A-D
        
     // rest:   -- , A token token D , -- A D --

         removeWrongPairs();             //remove fel pairs from acronymPairs
}


 private void chooseOnePair(String acr, String def1, String def2){
   String definition="";
   SubSequence lcs1 = new  SubSequence(def1, acr);
   SubSequence lcs2 = new  SubSequence(def2, acr);
   String def11 = lcs1.getLcS();
   String def22 = lcs2.getLcS();
   if(def11=="")
     definition = def22;
   if(def22=="")
     definition = def11;

   if(definition!=""){
     if(definition.endsWith(" "))
       definition = new String(definition.substring(0, definition.length()-1));
     acronymPairs.add(new Pair(acr, definition));
 }
 }
  private String findBestSubString(String defString){
    String token = "", newDefinition="";
    StringTokenizer stok = new StringTokenizer(defString);

       while(stok.hasMoreTokens()){
         token = stok.nextToken().trim();
         if(token.equals("t.ex.") || token.equals("ex")||token.equals("ex.")||
                token.equals("sk")  ||  token.equals("kallas") ||
                 token.equals("s.k.") || token.equals("k") || token.equals("enligt")
                || token.equals("(") || token.equals("[")){
               if(token.equals("(")){
                 if(defString.lastIndexOf("(")+2 >= defString.length()){
                   newDefinition = "";
                   break;
                 }
                 else if(defString.lastIndexOf(")")>-1){
                   newDefinition = new String(defString.substring(defString.lastIndexOf("(")+2, defString.indexOf(")")));
                   break;
                 }else{
                   newDefinition = defString.substring(defString.lastIndexOf("(")+2);
                   break;
                 }
               }
               /*else if( token.equals("och")  && defString.startsWith("och")){
                 newDefinition = new String(defString.substring(defString.lastIndexOf("och")+token.length()));
                   break;
		   }*/
               else{
                 if(defString.lastIndexOf(token)+2 >= defString.length()){
                  newDefinition ="";
                  break;
                 }
                 else{
                   newDefinition = new String(defString.substring(defString.lastIndexOf(token)+token.length()));
                  break;
                }
              }
            } 
	 newDefinition = defString;
          } //while
          if(newDefinition.startsWith(" "))
            newDefinition = new String(newDefinition.substring(1));
          if(newDefinition.endsWith(")"))
            newDefinition = new String(newDefinition.substring(0, newDefinition.indexOf(")")));
    return newDefinition;
  }

     /**
     * Saves the tokens in line in a new list which only contains the tokens
     * no pos tags
     * @param itr
     */
    public void getlistItrStr(ListIterator itr){
        for (ListIterator oneItr = itr; oneItr.hasNext(); ) {
        OnePair tokenInItr = (OnePair) oneItr.next();
        newLine.add(tokenInItr.getStr1());
      }
      }
      /**
       * addTag creates a list which contains the lines with the tagged acronym pairs
       * @param acr the string to tag as an acronym <acr> acr </acr>
       * @param def the string to tag as a definition <def> def </def>
       *
       */
      public void addTag(String acr, String def){
	  String acrtagStart ="<span style=\"background-color:#FFFF00\">";// "<acr>";
	  String acrtagEnd = "</span>";//"</acr>";
	  String deftagStart ="<span style=\"background-color:#00CC00\">";// "<def>";
	  String deftagEnd = "</span>";//"</def>";
        StringTokenizer defTokenizer = new StringTokenizer(def," ");
        String defToken = defTokenizer.nextToken().trim();
        String token ="";
        ListIterator lineItr = newLine.listIterator();

        while(lineItr.hasNext())
        {
          token = (String)lineItr.next();
          if(token.equals(acr)){
            token = acrtagStart + token.substring(0) +acrtagEnd ;
            lineItr.set(token);
          }
          //have to tokenize def
          if(token.equals(defToken)){
            if(!defTokenizer.hasMoreTokens()){
              token = deftagStart + token.substring(0) + deftagEnd;
              lineItr.set(token);
            }else{
                token = deftagStart + token.substring(0);
                lineItr.set(token);
                while(lineItr.hasNext() && defTokenizer.hasMoreTokens()){
                  token = (String)lineItr.next();
                  defToken = defTokenizer.nextToken().trim();
                 }
                 token = token.substring(0) + deftagEnd;
                 lineItr.set(token);
              }
            }
          }
        }
   private void removeWrongPairs(){
     for(Iterator pairsItr = acronymPairs.iterator(); pairsItr.hasNext(); ) {
       Pair acrPair = (Pair)pairsItr.next();
       String acrCandidate =acrPair.getAcronym();
       String defCandidate = acrPair.getDefinition();
       if(acrCandidate.length() >= defCandidate.length()
          || (countLetters(defCandidate) == acrCandidate.length())
          || (countLetters(defCandidate)+1 == acrCandidate.length()))
         acronymPairs.remove(acrPair);
         //if both strings only upper-case strings remove
//       if((countUpper(acrCandidate)== acrCandidate.length() || countUpper(acrCandidate)== acrCandidate.length()-1)&&
  //        (countUpper(defCandidate)== defCandidate.length() || countUpper(defCandidate)== defCandidate.length()-1))
       if(countUpper(defCandidate)== defCandidate.length() ||
         countUpper(defCandidate)== defCandidate.length()-1){
        acronymPairs.remove(acrPair);}
        if(defCandidate.indexOf("www.")>0 || defCandidate.indexOf("@")>0)
         acronymPairs.remove(acrPair);
           // if(containsChar(defCandidate))
             // acronymPairs.remove(acrPair);
          }
        }

      public boolean isAcronymCandidate(String candidateStr, String candidateTag) {
	  if ((acrTag(candidateTag) || (candidateTag.equals("X") && countUpper(candidateStr)>=2))
          && !noiseWord(candidateStr) && !names(candidateStr)
          && !containsChar(candidateStr) && //(Character.isUpperCase(candidateStr.charAt(0))
	            candidateStr.length() > 1 && !candidateStr.endsWith(".") &&
	  ( candidateStr.length() < 5 || (candidateStr.length() > 4 && candidateStr.length() < 14 
					  && countUpper(candidateStr)>=2)))
	  // && 
	  //(countUpper(candidateStr) > 0
	  //|| countUpper(candidateStr) < 1 && candidateStr.length() < 4))
        return true;
      return false;
    }

      /*
       * aTag(char tag)
       * Checks weather a tag is in the list of tags
       * @param tag The tag to be checked
       * @return true is tag is equal to one of the tags in the tag list
       *
       */
      private boolean aTag(char tag) {
        //int i=0;
        char[] tags = {
            'N', 'F', 'S', 'A', 'V', 'C', 'R', 'X', 'D', 'M', 'P', 'Y', 'Z', 'I'};
        for (int i = 0; i < tags.length; i++) {
          if (tags[i] == tag)
            return true;
        }
        return false;
      }

      /**
       *
       *
       * @param tag
       * @return
       */
    private boolean acrTag(String tag) {
      String[] tags = {
          "N", "Y"};
      for (int i = 0; i < tags.length; i++) {
        if (tags[i].equals(tag))
          return true;
      }
      return false;
    }
    /**
     *
     * @param word
     * @return
     */
   private boolean names(String word) {
     String[] words = {
         "Hans", "Klaus", "St�hr", "Liedholm","Jan-Peter","Str�mgren",
     "Reinhold","Kihlberg","The-Hung Bui", "Thorkild Nielsen","Lars","S�derhjelm"};
     for (int i = 0; i < words.length; i++) {
       if (words[i].equals(word))
         return true;
     }
      return false;
   }
   /**
    *
    * @param word is the string to check
    * @return true if word is in the list of noise words
    */
   private boolean noiseWord(String word) {
         String[] words = {"of","the","and","mg","ml","�r","ex","to","or","is","mm","�m","By","by","cm",//"The",
         "jan","feb","march","april","may","maj","juny","juni","july","juli","sep","oct","nov","dec","USA"};
      for (int i = 0; i < words.length; i++) {
        if(words[i].equals(word))
        return true;
      }
      return false;
   }
    /**
    * Counts the letters in the string
    * @param str is the string to check
    * @return the number of the letters in the string 
    */
   private int countLetters(String str) {
     int count=0;
     for (int i=0; i < str.length() ; i++)
       if (Character.isLetter(str.charAt(i)))
         count++;
     return count;
   }

   /**
    * Checks whether a string contains special characters
    * @param str is the string to check
    * @return true if str contains one of the characters '>','<','@','='
    */
   private boolean containsChar(String str) {
     for (int i=0; i < str.length() ; i++)
       if (str.charAt(i) == '<' ||str.charAt(i) == '>'
           || str.charAt(i) == '['|| str.charAt(i) == ']'
           || str.charAt(i) == '(' || str.charAt(i) == ')'  || str.charAt(i) == '�'
           || str.charAt(i) == '=' || str.charAt(i) == '@')
         return true;
     return false;
   }
   /**
    * Counts the number of upper-case letters
    * @param str is the string to check
    * @return the number of upper-case letters
    */
   private int countUpper(String str) {
     int upperCaseLetter = 0;
     for (int i=0; i < str.length() ; i++)
       if (Character.isUpperCase(str.charAt(i)))
         upperCaseLetter++;
     return upperCaseLetter;
   }
   /**
    *
    * @param oneLine
    */

   public void showThisLine(LinkedList oneLine){
      for (ListIterator linesItr = oneLine.listIterator(); linesItr.hasNext(); ) {
        OnePair line = (OnePair)linesItr.next();
       System.out.print(line.getStr1() +" " +line.getStr2() + " ");
       // System.out.println();
      }
    }

   public void showLine(LinkedList oneLine){
     for (ListIterator linesItr = oneLine.listIterator(); linesItr.hasNext(); ) {
       //OnePair line = (OnePair)linesItr.next();
       String str = (String)linesItr.next();
       System.out.print(str+" ");
      // System.out.print(line.getStr1() +" " +line.getStr2() + " ");
       //System.out.println();
     }
   }
public Iterator getAcronymsInLines(){
    return acronymsInlines.iterator();
}
   /**
   *
   * <p>Title: </p>
   * <p>Description: </p>
   * <p>Copyright: Copyright (c) 2006</p>
   * <p>Company: </p>
   * @author not attributable
   * @version 1.0
   
 private class OnePair{
   String str1;
   String str2;
   String stringsContext;
   LList allAcronym;
   LinkedList inLine;

   /**
    *
    * @param str1
    * @param str2
    
   private OnePair(String str1, String str2){
     this.str1 = str1;
     this.str2 = str2;
   }

   private OnePair(LList allAcronym, LinkedList inLine){
    this.allAcronym = allAcronym;
    this.inLine = inLine;
  }
   public String getStr1(){
     return this.str1;
   }
   public String getStr2(){
     return this.str2;
   } 
     public LList getAcrList(){
     return this.allAcronym;
   } 
     public LinkedList getLineList(){
     return this.inLine;
   }
 }*/

    /*public void printResults(){
AcrCandidatesFromFile candidatesList = new AcrCandidatesFromFile();
  for(Iterator candidatesItr = candidatesList.getCandidates();candidatesItr.hasNext(); ) {
    Pair oneCandidate = (Pair) candidatesItr.next();
    checkIfCorrect(oneCandidate.getAcronym(),oneCandidate.getDefinition());
  }
  }*/
 

 
  public boolean printnotFound(String acr) {
 for(Iterator pairsItr = allAcronymPairs.iterator(); pairsItr.hasNext(); ) {
       Pair acrPair = (Pair)pairsItr.next();
       if(acrPair.getAcronym().equals(acr))
	   return true;
 }return false;
	       
      /*try {
               PrintWriter outFile = new PrintWriter(new FileWriter("notFound.txt"));
               for (Iterator acrItr = allAcronymPairs.iterator(); acrItr.hasNext(); ) {
                   Pair acr = (Pair) acrItr.next();

                   outFile.print((String) acr.getAcronym() + "\t" +
                                  (String) acr.getDefinition());
                   outFile.println();
               }
               outFile.close();
           } catch (IOException ex) {
               System.err.println("ERROR: IOException: " + ex.getMessage());
               System.exit(0);
           }*/
  }

    public int getFoundCandidates() {
	return allAcronymPairs.size();
	} 
    public int getCorrect() {
	return correct;
	} 
    public int getTotalCorrect() {
	return  acrDictionary.getDictionarySize();
    }
  public void checkIfCorrect(String acrCandidate,String defCandidate){
	if(checkCorrect(acrCandidate,defCandidate))
	    correct++;
    }

      public boolean checkCorrect(String acrCandidate, String defCandidate){
       	for (Iterator acrItr = acrDictionary.getDictionaryItr(); acrItr.hasNext(); ) {
	//		for (Iterator acrItr = acrDictionary.iterator(); acrItr.hasNext(); ) {
	    Pair acr = (Pair) acrItr.next();
 
	    //        if(acr.getAcronym().equals(acrCandidate) && acr.getDefinition().equals(defCandidate))
          	 if(acr.getAcronym().equals(acrCandidate))
           return true;
   }
  return false;

  }

     public void printCandidates() {
           try {
               PrintWriter outFile = new PrintWriter(new FileWriter("candidatesFound.txt"));
               for (Iterator acrItr = allAcronymPairs.iterator(); acrItr.hasNext(); ) {
                   Pair acr = (Pair) acrItr.next();

                   outFile.print((String) acr.getAcronym() + "\t" +
                                  (String) acr.getDefinition());
                   outFile.println();
               }
               outFile.close();
           } catch (IOException ex) {
               System.err.println("ERROR: IOException: " + ex.getMessage());
               System.exit(0);
           }
     }
 public static void printAcronymsInLines(Iterator itr) {
           try {
               PrintWriter outFile = new PrintWriter(new FileWriter("candidatesInLine.txt"));
               for (Iterator acrItr = itr; acrItr.hasNext(); ) {
                   OnePair acrsInLine = (OnePair) acrItr.next();

		   List<Pair> arcslist =  acrsInLine.getAcrList();
		   List<String> arcsline = acrsInLine.getLineList();

		   for (Iterator acrsLineItr = arcsline.iterator(); acrsLineItr.hasNext(); ) {
		       String str = (String) acrsLineItr.next();
		        outFile.print(str +" ");
		   }
		   outFile.println();
		   for (Iterator acrsItr = arcslist.iterator(); acrsItr.hasNext(); ) {
		       Pair acrPair = (Pair) acrsItr.next();
                   outFile.print((String) acrPair.getAcronym() + "\t" +
                                  (String) acrPair.getDefinition());
                   outFile.println();
		   }
		    outFile.println();
               }
               outFile.close();
           } catch (IOException ex) {
               System.err.println("ERROR: IOException: " + ex.getMessage());
               System.exit(0);
           }
     }



    public static void main(String[] args) {
	AcronymRecognizer acronymRecognizer1 = new AcronymRecognizer("acronymsCorpusNoTags.annToken.tts", "acrLex.txt");
    //Iterator itr = acronymRecognizer1.getAcronymsInLines();
    //printAcronymsInLines(itr);
    }
}
