import java.text.*;
import java.util.*;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2005</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class SubSequence{
    private String	x, y;
    private int [][]	c;
    private char [][]	b;
    private char SPACE;
    public String lcs, str;
    
    public SubSequence( String f, String s) {
      x = " " + f;
      y = " " + s;
      SPACE = ' ';
      initialize();
      display();
    }
    private void initialize()
    {
	int	m = x.length() + 1,
	    n = y.length() + 1;
	c = new int[ m ][ n ];
	b = new char[ m ][ n ];
	
	for ( int i = 0; i < m; i++ )
	    c[ i ][ 0 ] = 0;
	for ( int j = 0; j < n; j++ )
	    c[ 0 ][ j ] = 0;
    }
    
    public void display()
    {
	int	m = x.length() - 1,
	      n = y.length() - 1;
	LcsString();
	
    }
    
    private void LcsString()
    {
	int m = x.length() - 1, n = y.length() - 1;
        while ( ( m > 0 ) && ( n > 0 ) )
	    if ( x.charAt( m ) == Character.toLowerCase(y.charAt( n ))
		 || x.charAt( m ) == Character.toUpperCase(y.charAt( n ))
		 ) {
		m--;
		n--;
	    } else if ( c[ m ][ n ] == c[ m - 1 ][ n ] )
		m--;
	    else
		n--;
        int start = m;
        while(start > 0 && x.charAt(start) != SPACE)
	    start--;
	
	if(x.equals(x.substring(start)))
	    lcs ="";
	else
	    lcs = x.substring(start);
    }
    public String getLcS(){
	return lcs;
	
    }
    public static void main( String [] args )
      {
	  //  String second= "EHEC";
	  //String   first= "infektion med entero||hemorragisk E.coli";
	  String second= "MTHFR";
    String first="det   metylenetetrahydrofolate reductase )";//mediciner mot multipel skleros";
 SubSequence ss = new SubSequence ( first, second );
    //System.out.println(ss.getLcS() + "" +second.length());
    //String i= first.substring(first.lastIndexOf(")"),first.length());
    String[] tokenNr = first.split("\\s");
    System.out.println( first.substring(0,first.indexOf(")"))+" "+ first.length());
    //ss.fillTable();
   // System.out.println(ss.display());
      }
}
