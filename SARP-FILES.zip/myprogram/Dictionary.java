
import java.io.*;
import java.util.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2006</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class Dictionary{
    List<Pair> acronyms;
    String dictionaryFile;
    
  public Dictionary(String dictionaryFile) {
     acronyms = new LinkedList<Pair>();
     this.dictionaryFile = dictionaryFile;
     getAllPairs();
  }

    public void getAllPairs(){
     try {
          BufferedReader in = new BufferedReader(new FileReader(dictionaryFile));
          String str = in.readLine();
          while (str != null) {
            StringTokenizer st = new StringTokenizer(str,"\t");
       	    String number = st.nextToken().trim();
	    String acr = st.nextToken().trim();
	    String def = st.nextToken().trim();
	    acronyms.add(new Pair(acr,def));
          str = in.readLine();
	  }
	  in.close();
     } catch(NoSuchElementException ex) {
	 System.err.println("ERROR: Dictionary file formated incorrectly. LEX");
	 System.exit(0);
     } catch (FileNotFoundException ex) {
	 System.err.println("ERROR: Couldn't find " +  dictionaryFile );
	 System.exit(0);
     } catch (IOException ex) {
	 System.err.println("ERROR: IOException: " + ex.getMessage());
	 System.exit(0);
     }
    }
    public Iterator getDictionaryItr()
    {
	return acronyms.iterator();
    }
    public int getDictionarySize()
    {
	return acronyms.size();
    }
    
    // public static void main(String[] args) {
    // AcrLex acrLex1 = new AcrLex();
    //System.out.println(acrLex1.getSize());
    // }   
}
